import { IUser } from '../interfaces/IUser';
import { UserModel } from '../models/User';

export interface IUserRepository {
  create(user: IUser): Promise<IUser>;
  findByEmail(email: string): Promise<IUser | null>;
}

export class UserRepository implements IUserRepository {
  async create(user: IUser): Promise<IUser> {
    const created = new UserModel(user);
    return await created.save();
  }

  async findByEmail(email: string): Promise<IUser | null> {
    return await UserModel.findOne({ email }).exec();
  }
}
