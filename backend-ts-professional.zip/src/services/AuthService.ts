import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { IUserRepository } from '../repositories/UserRepository';
import { IUser } from '../interfaces/IUser';

export interface IAuthService {
  register(name: string, email: string, password: string): Promise<IUser>;
  login(email: string, password: string): Promise<{ user: IUser; token: string }>;
}

export class AuthService implements IAuthService {
  constructor(private userRepo: IUserRepository) {}

  async register(name: string, email: string, password: string): Promise<IUser> {
    const existing = await this.userRepo.findByEmail(email);
    if (existing) throw new Error('User already exists');
    const hashed = await bcrypt.hash(password, 10);
    const user: IUser = { name, email, password: hashed, isVerified: false };
    return await this.userRepo.create(user);
  }

  async login(email: string, password: string): Promise<{ user: IUser; token: string }> {
    const user = await this.userRepo.findByEmail(email);
    if (!user) throw new Error('Invalid credentials');
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) throw new Error('Invalid credentials');
    const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET as string, { expiresIn: '1d' });
    return { user, token };
  }
}
