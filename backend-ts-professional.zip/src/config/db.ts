import mongoose from 'mongoose';
import dotenv from 'dotenv';
dotenv.config();

export class Database {
  private static instance: Database;
  private constructor() {}

  public static async connect(): Promise<void> {
    if (Database.instance) return;
    try {
      const conn = await mongoose.connect(process.env.MONGO_URI as string);
      console.log(`MongoDB Connected: ${conn.connection.host}`);
      Database.instance = new Database();
    } catch (error) {
      console.error(`DB Connection Error: ${error}`);
      process.exit(1);
    }
  }
}
