import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { Database } from './config/db';

dotenv.config();
Database.connect();

const app = express();
app.use(express.json());
app.use(cors());

// Import routes
import authRoutes from './routes/authRoutes';
// TODO: import other modules' routes

// Mount routes
app.use('/api/auth', authRoutes);
// TODO: mount other routes

export default app;
